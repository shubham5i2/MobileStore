package com.cg.doctorappointment.iquerymapper;

public interface QueryMapper 
{
	public static String QUERY1="select doc_id,hosp_name,loc,city,time,status from Doc_Appointment where city=? AND hosp_name=? AND status='A'";
	public static String QUERY2="update Doc_Appointment set status='NA' where doc_id=?";
}
