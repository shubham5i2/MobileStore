package com.cg.doctorappointment.util;

import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;



public class DatabaseConn 
{
	static Connection connection=null;
	public Connection Conn()
	{
		InitialContext initialContext;
		try
		{
			initialContext = new InitialContext();
			DataSource dataSource=(DataSource) initialContext.lookup("java:/jdbc/OracleDS");
			connection=dataSource.getConnection();
		}
		 catch (Exception e) 
		{
			e.printStackTrace();
		}
		return connection;
	}
}
