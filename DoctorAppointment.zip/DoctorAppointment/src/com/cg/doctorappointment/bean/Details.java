package com.cg.doctorappointment.bean;

public class Details 
{
	private String city;
	private String hname;
	private int docID;
	private String loc;
	private String time;
	private String status;
	
	
	public int getDocID() 
	{
		return docID;
	}
	public void setDocID(int docID) 
	{
		this.docID = docID;
	}
	public String getLoc() 
	{
		return loc;
	}
	public void setLoc(String loc) 
	{
		this.loc = loc;
	}
	public String getTime() 
	{
		return time;
	}
	public void setTime(String time) 
	{
		this.time = time;
	}
	public String getStatus() 
	{
		return status;
	}
	public void setStatus(String status) 
	{
		this.status = status;
	}
	public String getCity() 
	{
		return city;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	public String getHname() 
	{
		return hname;
	}
	public void setHname(String hname) 
	{
		this.hname = hname;
	}
	
	
}
