package com.cg.doctorappointment.service;

import java.util.ArrayList;

import com.cg.doctorappointment.bean.Details;
import com.cg.doctorappointment.exception.DatabaseConnectionException;

public interface IDoctorService 
{
	public ArrayList<Details> getDetails(String city,String hname) throws DatabaseConnectionException;
	public boolean updateDetails(int id) throws DatabaseConnectionException;
}
