package com.cg.doctorappointment.service;

import java.util.ArrayList;

import com.cg.doctorappointment.bean.Details;
import com.cg.doctorappointment.dao.DoctorDaoImpl;
import com.cg.doctorappointment.exception.DatabaseConnectionException;

public class DoctorServiceImpl implements IDoctorService 
{

	@Override
	public ArrayList<Details> getDetails(String city, String hname) throws DatabaseConnectionException 
	{
		ArrayList<Details> list=new ArrayList<Details>();
		DoctorDaoImpl dao=new DoctorDaoImpl();
		list=dao.getDetails(city, hname);
		return list;
	}

	@Override
	public boolean updateDetails(int id) throws DatabaseConnectionException 
	{
		boolean res=false;
		DoctorDaoImpl dao=new DoctorDaoImpl();
		res=dao.updateDetails(id);
		return res;
	}
}
