package com.cg.doctorappointment.dao;

import java.util.ArrayList;

import com.cg.doctorappointment.bean.Details;
import com.cg.doctorappointment.exception.DatabaseConnectionException;

public interface IDoctorDao 
{
	public ArrayList<Details> getDetails(String city,String hname) throws DatabaseConnectionException;
	public boolean updateDetails(int id) throws DatabaseConnectionException;
}
