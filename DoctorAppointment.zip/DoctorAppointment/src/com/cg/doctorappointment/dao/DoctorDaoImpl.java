package com.cg.doctorappointment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.doctorappointment.bean.Details;
import com.cg.doctorappointment.exception.DatabaseConnectionException;
import com.cg.doctorappointment.iquerymapper.QueryMapper;
import com.cg.doctorappointment.util.DatabaseConn;

public class DoctorDaoImpl implements IDoctorDao
{		
	ArrayList<Details> list=new ArrayList<Details>();
	int result=0;
	boolean value;
	DatabaseConn db=new DatabaseConn();
	PreparedStatement p,p1;
	ResultSet rs=null;
	static Connection conn=null;
	@Override
	public ArrayList<Details> getDetails(String city, String hname) throws DatabaseConnectionException 
	{
		Logger DoctorLogger = Logger.getLogger(DoctorDaoImpl.class.getName());
		PropertyConfigurator.configure("D:/Module-3/Workspace_module-2/DoctorAppointment/resources/log4j.properties");
		try
		{
			conn=db.Conn();
			p=conn.prepareStatement(QueryMapper.QUERY1);
			p.setString(1, city);
			p.setString(2, hname);
			p.executeUpdate();
			ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				Details det=new Details();
				det.setDocID(rs.getInt(1));
				det.setHname(rs.getString(2));
				det.setLoc(rs.getString(3));
				det.setCity(rs.getString(4));
				det.setTime(rs.getString(5));
				det.setStatus(rs.getString(6));
				list.add(det);
			}
			
		}
		catch(Exception e)
		{
			throw new DatabaseConnectionException("Something went wrong!!! Try again later");		
		}
		return list;
	}
	@Override
	public boolean updateDetails(int id) throws DatabaseConnectionException 
	{
		try
		{
			p1=conn.prepareStatement(QueryMapper.QUERY2);
			p1.setInt(1, id);
			int val=p1.executeUpdate();
			if(val==1)
			{
				value=true;			}
			else
			{
				value=false;
			}
		}
		catch(Exception e)
		{
			throw new DatabaseConnectionException("Something went wrong!!! Try again later");
		}
		
		return value;
	}

}
