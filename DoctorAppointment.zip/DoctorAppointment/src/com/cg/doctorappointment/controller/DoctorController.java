package com.cg.doctorappointment.controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.doctorappointment.bean.Details;
import com.cg.doctorappointment.exception.DatabaseConnectionException;
import com.cg.doctorappointment.service.DoctorServiceImpl;

/**
 * Servlet implementation class DoctorController
 */
@WebServlet("/DoctorController")
public class DoctorController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		boolean result = false;
		String option=request.getParameter("book");
		DoctorServiceImpl doc=new DoctorServiceImpl();
		if(option.equals("Search"))
		{
			ArrayList<Details> list=new ArrayList<>();
			String city=request.getParameter("city");
			String hname=request.getParameter("hname");
			
			try 
			{
				list=doc.getDetails(city, hname);
			}
			catch (DatabaseConnectionException e) 
			{
				e.printStackTrace();
			}
			if(list!=null)
			{
				request.setAttribute("list", list);
				request.getRequestDispatcher("Book.jsp").forward(request, response);
			}
			else
			{
				response.getWriter().print("<b>No appointments are available with this credentials!!!<b>");
			}
		}
		
		else if(option.equals("Book Appointment"))
		{
			int id=Integer.parseInt(request.getParameter("docID"));
			try 
			{
				result=doc.updateDetails(id);
			} 
			catch (DatabaseConnectionException e) 
			{
				e.printStackTrace();
			}
			if(result)
			{
				request.getRequestDispatcher("success.jsp").forward(request, response);
			}
			else
			{
				request.getRequestDispatcher("failure.jsp").include(request, response);
			}
		}
	}

}
