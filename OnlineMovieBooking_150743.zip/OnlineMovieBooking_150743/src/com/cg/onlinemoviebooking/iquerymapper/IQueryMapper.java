package com.cg.onlinemoviebooking.iquerymapper;

public interface IQueryMapper 
{
	String MESSAGE1 ="SELECT theatre_name,theatre_location,show_timing,status,movie_id FROM movie_master WHERE city=? AND movie_name=? AND status=?";
	String MESSAGE2 ="UPDATE movie_master SET status=? WHERE movie_id=?";
}