package com.cg.onlinemoviebooking.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.onlinemoviebooking.exception.IExceptionMessage;
import com.cg.onlinemoviebooking.exception.MovieException;

public class DataBaseConn 
{
	static Connection connection=null;
	public Connection Conn() throws MovieException
	{
		InitialContext initialContext;
		try
		{
			initialContext = new InitialContext();
			DataSource dataSource=(DataSource) initialContext.lookup("java:/jdbc/OracleDS");
			connection=dataSource.getConnection();
		}
		catch (Exception e) 
		{
			throw new MovieException(IExceptionMessage.ERROR2);
		}
		return connection;
	}
}
