package com.cg.onlinemoviebooking.controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.onlinemoviebooking.bean.MovieDetailsBean;
import com.cg.onlinemoviebooking.exception.IExceptionMessage;
import com.cg.onlinemoviebooking.exception.MovieException;
import com.cg.onlinemoviebooking.service.MovieService;

/**
 * Servlet implementation class MovieController
 */
@WebServlet("/MovieController")
public class MovieController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	MovieService service=new MovieService();
	boolean result = false;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession(); //Session is created
		try 
		{
			if(request.getParameter("proceed").equalsIgnoreCase("Proceed")) //Here button value is checked and then proceeded
			{
				ArrayList<MovieDetailsBean> list = new ArrayList<MovieDetailsBean>();
				String cityName = request.getParameter("city");
				String movieName = request.getParameter("movie");
				list=service.retrieveDetails(movieName, cityName);
				if (!list.isEmpty()) 
				{
					session.setAttribute("cityName", cityName);
					session.setAttribute("movieName", movieName);
					session.setAttribute("list", list);
					getServletContext().getRequestDispatcher("/views/MovieDetails.jsp").include(request, response);
				} 
				else 
				{
					throw new MovieException(IExceptionMessage.ERROR1); //User defined exception is thrown
				}
			} 
			else 
			{
				String movieId = request.getParameter("movieId"); //Retrieves movieID from MovieDetails.jsp page and stores in variable movieId
				session.setAttribute("movieId", movieId);
				System.out.println(movieId);
				result =service.updateStatus(movieId);
				if (result) 
				{
					getServletContext().getRequestDispatcher("/views/Success.jsp").include(request, response); //goes to success.jsp and prints success message
				}
				else
				{
					getServletContext().getRequestDispatcher("/views/Failure.jsp").include(request, response);  //goes to success.jsp and prints failure message
				}
			}
		} 
		catch (MovieException de) 
		{
			request.setAttribute("errorMessage", de.getMessage());
			getServletContext().getRequestDispatcher("/views/Failure.jsp").forward(request, response);
		}
	}
}
