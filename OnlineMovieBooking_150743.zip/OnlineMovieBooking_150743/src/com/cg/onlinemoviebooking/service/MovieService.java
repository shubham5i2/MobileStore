package com.cg.onlinemoviebooking.service;

import java.util.ArrayList;
import com.cg.onlinemoviebooking.bean.MovieDetailsBean;
import com.cg.onlinemoviebooking.dao.MovieDAO;
import com.cg.onlinemoviebooking.exception.MovieException;

public class MovieService implements IMovieService {
	private MovieDAO movieDao = null;

	public MovieService() {
		movieDao = new MovieDAO();
	}

	@Override
	public ArrayList<MovieDetailsBean> retrieveDetails(String movieName,String movieCity) throws MovieException {
		ArrayList<MovieDetailsBean> list = new ArrayList<MovieDetailsBean>();
		list = movieDao.retrieveDetails(movieName, movieCity);
		return list;
	}

	@Override
	public boolean updateStatus(String movieId) throws MovieException {
		boolean result = false;
		result = movieDao.updateStatus(movieId);
		return result;
	}

}
