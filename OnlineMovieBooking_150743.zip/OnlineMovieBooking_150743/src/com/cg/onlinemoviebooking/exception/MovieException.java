package com.cg.onlinemoviebooking.exception;

public class MovieException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieException() 
	{

	}

	public MovieException(String str) 
	{
		super(str);
	}

}
