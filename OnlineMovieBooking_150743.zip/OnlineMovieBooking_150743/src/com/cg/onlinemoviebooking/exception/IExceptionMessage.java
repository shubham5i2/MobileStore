package com.cg.onlinemoviebooking.exception;

public interface IExceptionMessage 
{
	String ERROR1 = "City name/Movie name not found";
	String ERROR2 = "Something went wrong!!! Try again later";
}
