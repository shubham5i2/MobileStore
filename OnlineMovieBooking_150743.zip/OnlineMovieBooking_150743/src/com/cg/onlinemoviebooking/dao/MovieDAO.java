package com.cg.onlinemoviebooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.onlinemoviebooking.bean.MovieDetailsBean;
import com.cg.onlinemoviebooking.exception.IExceptionMessage;
import com.cg.onlinemoviebooking.exception.MovieException;
import com.cg.onlinemoviebooking.iquerymapper.IQueryMapper;
import com.cg.onlinemoviebooking.util.DataBaseConn;

public class MovieDAO implements IMovieDAO
{
	int result=0;
	boolean value;
	DataBaseConn db=new DataBaseConn();
	PreparedStatement p,p1;
	ResultSet rs=null;
	static Connection conn=null;

	@Override
	public ArrayList<MovieDetailsBean> retrieveDetails(String movieName,String movieCity) throws MovieException 
	{
		ArrayList<MovieDetailsBean> list=new ArrayList<MovieDetailsBean>();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try
		{
			conn=db.Conn();
			if(conn==null)
			{
				throw new MovieException(IExceptionMessage.ERROR2); //User defined exception is thrown
			}
			preparedStatement=conn.prepareStatement(IQueryMapper.MESSAGE1);
			preparedStatement.setString(1, movieCity);
			preparedStatement.setString(2, movieName);
			preparedStatement.setString(3, "Available");
			preparedStatement.executeQuery();
			resultSet = preparedStatement.getResultSet();
			if(!resultSet.isBeforeFirst()) 
			{
				throw new MovieException(IExceptionMessage.ERROR1); //User defined exception is thrown
			}
			while (resultSet.next()) 
			{
				MovieDetailsBean movieDetailsbean = new MovieDetailsBean();
				movieDetailsbean.setTheatreName(resultSet.getString(1));
				movieDetailsbean.setTheatreLocation(resultSet.getString(2));
				movieDetailsbean.setShowTiming(resultSet.getString(3));
				movieDetailsbean.setStatus(resultSet.getString(4));
				movieDetailsbean.setMovieId(resultSet.getString(5));
				list.add(movieDetailsbean);
			}
		}
		catch(Exception e)
		{
			throw new MovieException(IExceptionMessage.ERROR1);	//User defined exception is thrown
		}

		return list;
	}

	@Override
	public boolean updateStatus(String movieId) throws MovieException 
	{
		boolean value = false;
		int res;
		PreparedStatement preparedStatement;
		try {
			preparedStatement=conn.prepareStatement(IQueryMapper.MESSAGE2);
			preparedStatement.setString(1,"NotAvailable");
			preparedStatement.setString(2,movieId);
			res=preparedStatement.executeUpdate();
			if(res==1)
			{
				value=true;
			}
			else
			{
				value=false;
			}
		} 
		catch (Exception e) 
		{
			throw new MovieException(IExceptionMessage.ERROR2); //User defined exception is thrown
		}
		return value;
	}

}
