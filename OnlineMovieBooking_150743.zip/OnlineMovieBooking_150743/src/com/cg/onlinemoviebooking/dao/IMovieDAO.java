package com.cg.onlinemoviebooking.dao;

import java.util.ArrayList;

import com.cg.onlinemoviebooking.bean.MovieDetailsBean;
import com.cg.onlinemoviebooking.exception.MovieException;

public interface IMovieDAO 
{
	public ArrayList<MovieDetailsBean> retrieveDetails(String movieName, String movieCity) throws MovieException;
	public boolean updateStatus(String movieId) throws MovieException;
}
