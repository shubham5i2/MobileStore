package com.assignment.lab11.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.assignment.lab11.service.ServiceImplmntn;

public class DatabaseImplmntTest 
{

	@Before
	public void setUp() throws Exception 
	{
		
	}

	@After
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void test() 
	{
		ServiceImplmntn d=new ServiceImplmntn();
		assertEquals("",d.AddDetails().get(0));
	}

}
