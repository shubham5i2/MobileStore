package com.assignment.lab11.dao;

import java.util.List;

public interface DatabaseAccess 
{
	public List AddDetails(String name,String email,String phone);
	public void viewDetails();
	public void deleteDetails();
	public void searchMobiles();
}
