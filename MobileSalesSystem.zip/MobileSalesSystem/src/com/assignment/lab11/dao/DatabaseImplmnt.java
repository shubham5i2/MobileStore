package com.assignment.lab11.dao;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.assignment.lab11.beans.CustomerDetails;

public class DatabaseImplmnt implements DatabaseAccess
{
	Properties p=new Properties();
	java.util.Date d=new java.util.Date();
	java.sql.Date t=new java.sql.Date(d.getTime());
	CustomerDetails c=new CustomerDetails();


	int moblid;
	int quant;
	int left_quantity;
	String mobileID;
	Statement st;
	ResultSet rs1;
	ResultSet rs2;
	Connection con;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	PreparedStatement pst2=null;
	PreparedStatement pst3=null;
	PreparedStatement pst4=null;
	
	@Override
	public List AddDetails(String name,String email,String phone) 
	{
		ArrayList<String> list=new ArrayList<String>();
		try 
		{
			int count=0;
			//Database connectivity
			FileInputStream fi=new FileInputStream("D:/Module-2/Core Java/DB_PropFile.properties");
			p.load(fi);
			fi.close();
			String dr=p.getProperty("driver");
			String url=p.getProperty("url");
			String uname=p.getProperty("username");
			String pwd=p.getProperty("password");
			Class.forName(dr);
			con=DriverManager.getConnection(url,uname,pwd);
			st=con.createStatement();
			
		
			while(true)
			{
				System.out.println("Enter the customer mobile id: ");
				Scanner sc=new Scanner(System.in);
				mobileID=sc.nextLine();
				Pattern pat=Pattern.compile("^[0-9]{4}$");
				Matcher match=pat.matcher(mobileID);
				if(!match.find())
				{
					System.out.println("Please enter a valid mobile ID");
				}
				else
				{
					moblid=Integer.parseInt(mobileID);
					//System.out.println("Mobile ID is: "+moblid);
					rs1=st.executeQuery("SELECT * FROM mobiles");
					while(rs1.next()) //Mandatory to call this method called 'next()'
					{
						//System.out.println(rs.getInt(1));
						if((moblid==rs1.getInt("mobileid")) && (Integer.parseInt(rs1.getString("quantity")))>0)//this checks moblid with
						{																				//each mobile id in the database
							count+=1;
							//System.out.println("Count is: "+count);
							break;
						}
					}	
					if(count==0)
					{
						System.err.println("Either the entered mobile id is incorrect or quantity is empty");
					}
					else
					{
						break;
					}
				}
			}
			if(count>0)
			{	
				int temp=0;
				ResultSet rst=st.executeQuery("SELECT table_name FROM user_tables");
				while(rst.next())
				{
					if(rst.getString("table_name").equals("PURCHASEDETAILS"))
					{
						temp+=1;
					}
				}
				if(temp==0)
				{
					st.execute("CREATE TABLE purchasedetails(purchaseid NUMBER, cname vARCHAR2(20),mailid VARCHAR2(30),phoneno VARCHAR2(20), purchasedate DATE,mobileid references mobiles(mobileid) ON DELETE CASCADE)");
					st.execute("DROP SEQUENCE purchase_id");
					st.execute("CREATE SEQUENCE purchase_id INCREMENT BY 1 START WITH 1000 MAXVALUE 9999 NOCYCLE");
					temp=1;
				}

				if(temp>0)
				{
					pst=con.prepareStatement("INSERT INTO purchasedetails VALUES(purchase_id.NEXTVAL,?,?,?,?,?)");
					pst.setString(1,name);
					pst.setString(2,email);
					pst.setString(3,phone);
					pst.setDate(4,t);
					pst.setInt(5,moblid);
					pst.executeUpdate();
				}
				while(true)
				{
					int cnt=0;
					System.out.println("How many mobiles do you need? Enter atleat one...");
					Scanner sc1=new Scanner(System.in);
					quant=sc1.nextInt();
					pst1=con.prepareStatement("SELECT quantity FROM mobiles WHERE mobileid=?");
					pst1.setInt(1,moblid);
					rs2=pst1.executeQuery(); //This stores quantity of mobile based on mobileID given by the user
					while(rs2.next())
					{
						//System.out.println(rs2.getInt(1)); //Displays quantity based on mobileID selected by the user
						if(quant>Integer.parseInt(rs2.getString("quantity")))
						{
							System.err.println("Mobiles with this ID are out of stock");
							cnt+=1;
						}
					}
					if(cnt==0)
					{
						pst2=con.prepareStatement("UPDATE mobiles SET quantity=quantity-? WHERE mobileid=?");
						pst2.setString(1, Integer.toString(quant));
						pst2.setInt(2, moblid);
						pst2.executeUpdate();
						System.out.println("Updated successfully");
						break;
					}
				} //END of while
			} //END of if
		} //END of try 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		list.add(name);
		list.add(email);
		list.add(phone);
		return list;
	}

	@Override
	public void viewDetails() 
	{
		ResultSet rs3;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg311","training311");
			st=con.createStatement();
			rs3=st.executeQuery("SELECT mobileid,name,price,quantity FROM mobiles");
			while(rs3.next())
			{
				System.out.println(rs3.getInt(1)+"   \t   || "+rs3.getString(2)+"     ||"+rs3.getInt(3)+"   ||"+rs3.getString(4));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void deleteDetails() 
	{
		ResultSet rs4;
		int count=0;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg311","training311");
			st=con.createStatement();
			
			while(true)
			{
				System.out.println("Enter mobile-ID which you want to delete");
				Scanner sc=new Scanner(System.in);
				mobileID=sc.nextLine();
				Pattern pat=Pattern.compile("^[0-9]{4}$");
				Matcher match=pat.matcher(mobileID);
				if(!match.find())
				{
					System.out.println("Please enter a valid mobile ID");
				}
				else
				{
					moblid=Integer.parseInt(mobileID);
					//System.out.println("Mobile ID is: "+moblid);
					rs4=st.executeQuery("SELECT * FROM mobiles");
					while(rs4.next()) //Mandatory to call this method called 'next()'
					{
						//System.out.println(rs.getInt(1));
						if((moblid==rs4.getInt("mobileid")))//this checks moblid with
						{									//each mobile id in the database
							count+=1;
							//System.out.println("Count is: "+count);
							break;
						}
					}	
					if(count==0)
					{
						System.err.println("You have entered an invalid mobile ID...");
					}
					else
					{
						break;
					}
				}
			}
			if(count>0)
			{
				moblid=Integer.parseInt(mobileID);
				pst3=con.prepareStatement("DELETE FROM mobiles WHERE mobileid=?");
				pst3.setInt(1, moblid);
				pst3.executeUpdate();
				System.out.println("Mobile with this id is deleted successfully");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void searchMobiles() 
	{
		ResultSet rs5;
		int from,to;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg311","training311");
			st=con.createStatement();
			
			System.out.println("From: ");
			Scanner sc1=new Scanner(System.in);
			from=sc1.nextInt();
			System.out.println("To: ");
			Scanner sc2=new Scanner(System.in);
			to=sc2.nextInt();
			
			pst4=con.prepareStatement("SELECT * FROM mobiles WHERE price BETWEEN ? AND ?");
			pst4.setInt(1, from);
			pst4.setInt(2, to);
			pst4.executeUpdate();
			rs5=pst4.executeQuery();
			while(rs5.next())
			{
				System.out.println();
				System.out.println("Mobiles available in this price range is/are:\n"+rs5.getInt(1)+" "+rs5.getString(2)+" "+rs5.getInt(3)+" "+rs5.getString(4));
				System.out.println();
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
}
