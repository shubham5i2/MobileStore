package com.assignment.lab11.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.assignment.lab11.beans.CustomerDetails;
import com.assignment.lab11.dao.DatabaseImplmnt;

public class ServiceImplmntn implements Services
{
	String name,email,phone;
	DatabaseImplmnt d=new DatabaseImplmnt();
	CustomerDetails c=new CustomerDetails();//object 'c' is created to access various methods from CustomerDetails 
											//class in ServiceImplmntn class and both classes are in different packages
	
	@Override
	public List AddDetails() 
	{
		ArrayList<String> list=new ArrayList<String>();
		while(true)
		{
			System.out.println("Enter the name of the customer");
			Scanner sc1=new Scanner(System.in);
			name=sc1.nextLine();
			Pattern unp=Pattern.compile("[A-Z][a-z]{2,19}");
			Matcher mtcnn=unp.matcher(name);
			if(!mtcnn.find())
			{
				System.err.println("First character should be capital and max 20 characters are allowed");
			}
			else
			{
				c.setCust_name(name);
				//System.out.println(c.getCust_name()); /++++++++Displays customer name on the console
				break;
			}
		}
	
		while(true)
		{
			System.out.println("Enter the email of the customer");
			Scanner sc2=new Scanner(System.in);
			email=sc2.nextLine();
			Pattern emailp=Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
			Matcher mtce=emailp.matcher(email);
			if(!mtce.find())
			{
				System.err.println("Email should contain @ symbol");
			}
			else
			{
				c.setEmail(email);
				break;
			}
		}
		
		while(true)
		{
			System.out.println("Enter the mobile number of the customer");
			Scanner sc3=new Scanner(System.in);
			phone=sc3.nextLine();
			Pattern phonep=Pattern.compile("^[0-9]{10}$");
			Matcher mtcp=phonep.matcher(phone);
			if(!mtcp.find())
			{
				System.err.println("Please enter valid mobile number");
			}
			else
			{
				c.setPhoneno(phone);
				break;
			}
		}
		return d.AddDetails(name,email,phone);
		
	}

	@Override
	public void viewDetails() 
	{
		System.out.println("The available mobiles are\n");
		System.out.println("Mobile_id  ||     Mobile_name\t|| Price|| Quantity");
		System.out.println("---------------------------------------------------");
		d.viewDetails();
	}

	@Override
	public void deleteDetails() 
	{
		d.deleteDetails();	
	}

	@Override
	public void searchMobiles() 
	{
		System.out.println("Please enter two price range below...");
		d.searchMobiles();
	}
	
}
