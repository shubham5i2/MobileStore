package com.assignment.lab11.service;

import java.util.List;

public interface Services 
{
	public List AddDetails();
	public void viewDetails();
	public void deleteDetails();
	public void searchMobiles();
}
