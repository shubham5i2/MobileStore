package com.assignment.lab11.ui;
import java.util.*;
import java.io.*;

public class DB_Properties 
{
	public static void main(String[] args) 
	{
		try
		{
			Properties p=new Properties();
			p.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
			p.setProperty("url", "jdbc:oracle:thin:@10.219.34.3:1521:orcl");
			p.setProperty("username", "trg311");
			p.setProperty("password", "training311");
			File f=new File("D:/Module-2/Core Java/DB_PropFile.properties");
			FileOutputStream fo=new FileOutputStream(f);
			p.store(fo, "Oracle Database Details");
			fo.close();
			/*Enumeration<Object> enuKeys = p.keys();
			while (enuKeys.hasMoreElements()) 
			{
				String key = (String) enuKeys.nextElement();
				String value = p.getProperty(key);
				System.out.println(key + ": " + value);
			} */
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
