package com.assignment.lab11.ui;
import java.util.*;

import com.assignment.lab11.service.ServiceImplmntn;

public class MobileSales 
{
	public static void main(String[] args) 
	{
		int choiceMade;
		ServiceImplmntn s=new ServiceImplmntn();
		System.out.println("Welcome to Mobile sales");
		do
		{
			System.out.println("\n+++++++++++++++WELCOME TO MOBILE PURCHASE SYSTEM+++++++++++++++");
			System.out.println("Please selct one any option:");
			System.out.println("1.Add customer\n2.View mobiles\n3.Delete mobile details\n4.Search mobiles in the price range\n5.Exit");
			Scanner sc=new Scanner(System.in);
			choiceMade=sc.nextInt();
			switch (choiceMade) 
			{
				case 1:
					ArrayList<String> li=new ArrayList<String>();
					li=(ArrayList<String>) s.AddDetails();
					for(String str:li)
					{
						System.out.println(str);
					}
					break;
					
				case 2:
					s.viewDetails();
					break;
					
				case 3:
					s.deleteDetails();
					break;
				
				case 4:
					s.searchMobiles();
					break;
					
				case 5:
					System.out.println("Thank you for shopping with us!!! Have a good day");
					System.exit(0);
		
				default:
					System.err.println("Please make a valid choice");
					break;
			}
			
		}while(choiceMade!=5);
	}
}
