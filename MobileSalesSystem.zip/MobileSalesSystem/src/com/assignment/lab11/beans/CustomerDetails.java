package com.assignment.lab11.beans;

public class CustomerDetails 
{
	String cust_name;
	String email;
	String phoneno;
	public String getCust_name() 
	{
		return cust_name;
	}
	public void setCust_name(String cust_name) 
	{
		this.cust_name = cust_name;
	}
	public String getEmail() 
	{
		return email;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}
	public String getPhoneno() 
	{
		return phoneno;
	}
	public void setPhoneno(String phoneno) 
	{
		this.phoneno = phoneno;
	}
	
}
