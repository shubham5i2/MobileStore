package com.cg.assignment5.service;

import com.cg.assignment5.bean.Bill;
import com.cg.assignment5.bean.Consumer;
import com.cg.assignment5.dao.AsgnDaoImpl;

public class AsgnServiceImpl implements IAsgnService 
{
	int res;
	int result;
	@Override
	public int validateLogin(Consumer det) 
	{
		AsgnDaoImpl dao=new AsgnDaoImpl();
		res=dao.validateLogin(det);
		return res;
	}
	
	public int insertDetails(Bill b)
	{
		AsgnDaoImpl dao=new AsgnDaoImpl();
		result=dao.insertDetails(b);
		return result;
	}
}
