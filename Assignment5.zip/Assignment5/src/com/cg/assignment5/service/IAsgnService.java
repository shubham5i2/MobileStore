package com.cg.assignment5.service;

import com.cg.assignment5.bean.Bill;
import com.cg.assignment5.bean.Consumer;

public interface IAsgnService 
{
	public int validateLogin(Consumer det);
	public int insertDetails(Bill b);
}
