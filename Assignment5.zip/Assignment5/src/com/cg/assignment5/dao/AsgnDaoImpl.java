package com.cg.assignment5.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.assignment5.bean.Bill;
import com.cg.assignment5.bean.Consumer;
import com.cg.assignment5.util.DatabaseConn;

public class AsgnDaoImpl implements IAsgnDao 
{
	int result=0;
	int value=0;
	int val=0;
	DatabaseConn db=new DatabaseConn();
	PreparedStatement p1=null;
	PreparedStatement p2=null;
	Connection conn=null;
	static int cid;
	@Override
	public int validateLogin(Consumer det) 
	{
		try
		{
			conn=db.Conn();  
			p1=conn.prepareStatement("select * from log_info where uname=? AND password=?");
			p1.setString(1, det.getUname());
			p1.setString(2, det.getPass());
			result=p1.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public int insertDetails(Bill b) 
	{
		
		try
		{
			conn=db.Conn();  
			p1=conn.prepareStatement("select * from consumers where consumer_num=?");
			p1.setInt(1,b.getConnum());
			value=p1.executeUpdate();
			if(value==1)
			{
				p2=conn.prepareStatement("insert into BillDetails(bill_num,"
						+ "consumer_num, cur_reading,"
						+ "unitConsumed, netAmount) values(seq_bill_num.nextval,?,?,?,?)");
				p2.setInt(1,b.getConnum());
				p2.setInt(2, b.getCr());
				p2.setInt(3, b.getUc());
				p2.setDouble(4, b.getNa());
				val=p2.executeUpdate();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return val;
	}

}
