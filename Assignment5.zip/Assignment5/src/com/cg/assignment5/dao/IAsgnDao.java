package com.cg.assignment5.dao;

import com.cg.assignment5.bean.Consumer;
import com.cg.assignment5.bean.Bill;

public interface IAsgnDao 
{
	public int validateLogin(Consumer det);
	public int insertDetails(Bill b);
}
