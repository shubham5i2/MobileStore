package com.cg.assignment5.bean;

public class Bill 
{
	private int cr;
	private int uc;
	private double na;
	private int connum;
	
	public int getConnum() {
		return connum;
	}
	public void setConnum(int connum) {
		this.connum = connum;
	}
	public int getCr() {
		return cr;
	}
	public void setCr(int cr) {
		this.cr = cr;
	}
	public int getUc() {
		return uc;
	}
	public void setUc(int uc) {
		this.uc = uc;
	}
	public double getNa() {
		return na;
	}
	public void setNa(double na) {
		this.na = na;
	}
	
	
}
