package com.cg.assignment5.bean;

public class Consumer 
{
	private String uname;
	private String pass;
	private int lmr;
	private int cmr;
	
	public int getLmr() 
	{
		return lmr;
	}
	public void setLmr(int lmr) 
	{
		this.lmr = lmr;
	}
	public int getCmr() 
	{
		return cmr;
	}
	public void setCmr(int cmr) 
	{
		this.cmr = cmr;
	}
	public String getUname() 
	{
		return uname;
	}
	public void setUname(String uname) 
	{
		this.uname = uname;
	}
	public String getPass() 
	{
		return pass;
	}
	public void setPass(String pass) 
	{
		this.pass = pass;
	}
	
	
}
