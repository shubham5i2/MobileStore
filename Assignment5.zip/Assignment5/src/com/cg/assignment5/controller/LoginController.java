package com.cg.assignment5.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String user_name=request.getParameter("uname");
		String password=request.getParameter("pwd");
		
		int u_name=user_name.length();
		int pass=password.length();
		if((u_name>4) && (pass>4))
		{
			try
			{
				request.setAttribute("uname", user_name);
				request.setAttribute("pwd", password);
				getServletContext().getRequestDispatcher("/ConsumerController").include(request, response);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			} 
		}
		else
		{
			PrintWriter printWriter=response.getWriter();
			printWriter.print("<b>Length of user-name and password should be greater than 4 digits</b><br><br>");
			request.getRequestDispatcher("/login.html").include(request, response);
		}
	}

}
