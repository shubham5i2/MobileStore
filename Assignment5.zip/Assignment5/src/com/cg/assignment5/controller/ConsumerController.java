package com.cg.assignment5.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.assignment5.bean.Consumer;
import com.cg.assignment5.service.AsgnServiceImpl;

/**
 * Servlet implementation class ConsumerController
 */
@WebServlet("/ConsumerController")
public class ConsumerController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	Consumer det=new Consumer();
    int value=0;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		AsgnServiceImpl ser=new AsgnServiceImpl();
		String uname=(String)request.getAttribute("uname");
		String pwd=(String)request.getAttribute("pwd");
		det.setUname(uname);
		det.setPass(pwd);
		value=ser.validateLogin(det);
		if(value==1)
		{
			PrintWriter out=response.getWriter();
			out.print("<html>"
					+ "<head>"
					+ "<meta charset='ISO-8859-1'>"
					+ "<title>Insert title here</title>"
					+ "</head>"
					+ "<body>"
					+ "<form action='BillController' method='post'>"
					+ "Consumer Number: <input type='text' name='conum' required='required'><br>"
					+ "Last Month Meter Reading: <input type='text' name='lmr' required='required'><br>"
					+ "Current Month Meter Reading: <input type='text' name='cmr' required='required'><br>"
					+ "<input type='submit' value='Calculate Bill'>"
					+ "</form>"
					+ "</body>"
					+ "</html>");
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.print("Invalid Username and password");
			request.getRequestDispatcher("/login.html").include(request, response);
		}
	}

}
