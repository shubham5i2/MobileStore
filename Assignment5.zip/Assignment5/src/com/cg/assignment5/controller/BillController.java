package com.cg.assignment5.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.assignment5.bean.Bill;
import com.cg.assignment5.bean.Consumer;
import com.cg.assignment5.service.AsgnServiceImpl;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/BillController")
public class BillController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    int res=0;
    int connum;
    int uc;
    double na;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Bill b=new Bill();
		Consumer c=new Consumer();
		AsgnServiceImpl ser=new AsgnServiceImpl();
		connum=Integer.parseInt(request.getParameter("conum"));
		int lmr=Integer.parseInt(request.getParameter("lmr"));
		int cmr=Integer.parseInt(request.getParameter("cmr"));
		c.setLmr(lmr);
		c.setCmr(cmr);
		int lr=c.getLmr();
		int cr=c.getCmr();
		uc=cr-lr;
		na=(uc*1.15)+100;
		b.setConnum(connum);
		b.setUc(uc);
		b.setNa(na);
		b.setCr(cr);
		res=ser.insertDetails(b);
		if(res==1)
		{
			PrintWriter out=response.getWriter();
			out.print("Electricity Bill for consumer number- "+b.getConnum()+" is<br>");
			out.print("Unit Consumed:: "+uc+"<br>");
			out.print("Net Amount:: Rs."+na);
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.print("Invalid Consumer Number");
		}
	}
}
